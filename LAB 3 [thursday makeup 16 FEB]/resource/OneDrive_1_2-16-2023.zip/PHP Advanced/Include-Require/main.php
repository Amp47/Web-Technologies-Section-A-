<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php 
		require 'navbar.php';
	 ?>

	<p>This is main content</p>
	<?php 
		echo $x+$y;

		include 'footer.php';
	 ?>

</body>
</html>