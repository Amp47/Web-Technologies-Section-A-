<?php 

	$x=10;
	$y=5;
	
	echo "<h1>This is a navbar</h1>";

 ?>
 <h2>This is 2nd nabvbar</h2>