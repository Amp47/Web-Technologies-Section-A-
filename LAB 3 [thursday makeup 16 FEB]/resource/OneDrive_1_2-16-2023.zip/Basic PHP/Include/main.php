<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php include 'navbar.php'; 

		echo $var;

	?>



	<h1>This is main content</h1>

	<?php include 'footer.php' ?>

</body>
</html>