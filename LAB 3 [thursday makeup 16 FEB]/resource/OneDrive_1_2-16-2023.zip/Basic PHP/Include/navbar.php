
<h2>This is the Header</h2>
	<?php
		$var= 5;
	?>