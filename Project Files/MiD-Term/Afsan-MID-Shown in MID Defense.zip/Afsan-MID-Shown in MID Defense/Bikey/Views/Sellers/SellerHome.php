<?php
session_start();
include_once './../CommonLayer/SellerHeader.php';
?>
<?php
//check if the user is already logged in
if (!isset($_SESSION['username'])) {
    header('Location: ./SellerLogin.php');
    exit();
} ?>

<p class="fw-bold p-3">Welcome <?= $_SESSION["username"] ?></p>

<?php include_once './../CommonLayer/SellerFooter.php'; ?>