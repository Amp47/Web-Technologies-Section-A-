<?php
session_start();
include_once './../CommonLayer/SellerHeader.php';
//check if the user is already logged in
if (!isset($_SESSION['username'])) {
    header('Location: ./SellerLogin.php');
    exit();
} ?>
    <div class="container">
        <div class="main-body mt-5">
            <form action="../../Controllers/SellerProfileController.php" method="post"
                  enctype="multipart/form-data">
                <div class="row gutters-sm">
                    <div class="col-md-4 mb-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex flex-column align-items-center text-center">
                                    <img src="../../Static/Images/ProfilePictures/<?=$_SESSION["username"]?>.jpg" alt="Admin"
                                         class="rounded-circle" width="150">
                                    <div class="mt-3">
                                        <h4><?= $_SESSION["username"] ?></h4>
                                        <p class="text-secondary mb-1">Profession Seller</p>
                                    </div>
                                    <div>
                                        <input type="file" name="pfp" id="image" class="form-control">
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-8">
                        <div class="card mb-3">

                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">Username</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary">
                                        <input type="text" class="form-control" name="username"
                                               value="<?= $_SESSION["username"] ?> " readonly>

                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">Email</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary">
                                        <input type="text" class="form-control" name="email"
                                               value="<?= $_SESSION["user"]["email"] ?>">
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">Phone</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary">
                                        <input type="text" class="form-control" name="phone"
                                               value="<?= $_SESSION["user"]["phone"] ?>">
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">Address</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary">
                                        <input type="text" class="form-control" name="address"
                                               value="<?= $_SESSION["user"]["address"] ?>">
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">New Password</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary">
                                        <input type="password" class="form-control" name="password"
                                               value="">
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <input type="submit" class="btn btn-info px-4"
                                               value="Save Changes">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>


<?php include_once './../CommonLayer/SellerFooter.php'; ?>