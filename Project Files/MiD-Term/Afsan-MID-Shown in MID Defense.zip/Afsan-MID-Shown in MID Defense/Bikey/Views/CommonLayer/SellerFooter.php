<hr class="my-5">
<footer class="footer">
    <div class="container">
        <p class="text-muted text-center">&copy 2023 Web Technologies Project, Sec-[A], Spring, 2022-2023</p>
    </div>
</footer>
</body>

</html>