<?php
session_start();
$username = $_POST["username"];
$email = $_POST["email"];
$phone = $_POST["phone"];
$address = $_POST["address"];
$password = $_POST["password"];

$json = file_get_contents("./../Models/SellerUser.json");
$json = json_decode($json, true);
foreach ($json as $key => $value) {
    $_username = strtolower($value["username"]);
    $username = strtolower($_SESSION["username"]);
    if ($_username == $username) {
        $json[$key]["username"] = $username;
        $json[$key]["email"] = $email;
        $json[$key]["phone"] = $phone;
        $json[$key]["address"] = $address;
        $_SESSION["username"] = $username;
        if ($password != "") {
            $json[$key]["password"] = $password;
        }
        $_SESSION["user"] = $json[$key];
    }
}
//profile picture -> pfp
if (isset($_FILES['pfp'])) {
    $file_name = $_SESSION["username"];
    $file_tmp = $_FILES['pfp']['tmp_name'];
    $file_size = $_FILES['pfp']['size'];
    $file_type = $_FILES['pfp']['type'];

    $upload_dir = '../Static/Images/ProfilePictures/';
    $target_file = $upload_dir . $file_name . '.jpg';

    if (move_uploaded_file($file_tmp, $target_file)) {
        echo 'File uploaded successfully.';
    } else {
        echo 'File upload failed.';
    }
}

file_put_contents("./../Models/SellerUser.json", json_encode($json));
header('Location: ./../Views/Sellers/SellerProfile.php');
