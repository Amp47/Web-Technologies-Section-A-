<?php
$number = 39;
if($number % 2 == 0){
    echo "<b>Even</b>";
}
else{
    echo " <b>Odd</b>"; 
}
?>
