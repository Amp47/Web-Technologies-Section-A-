<?php  
 $length = 14;  
 $width = 12;  
 echo " <h3>Area of rectangle is $length * $width= " . ($length * $width) . " </h3><br />";   
  ?>  