<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task_6</title>
</head>
<body>
    Blood Group
    <form action="handaler.php" method="post">
    <select name="grp" id="">
        <option value="A+" >A+</option>
        <option value="A-" >A-</option>
        <option value="B+" >B+</option>
        <option value="B-" >B-</option>
        <option value="O+" >O+</option>
        <option value="O-" >O-</option>
        <option value="AB+" >AB+</option>
        <option value="AB-" >AB-</option>
    </select>
    
    <hr style="margin-left:0; max-width: 140px;">
    <input type="submit" name="submit" value="Submit">
    </form>
</body>
</html>