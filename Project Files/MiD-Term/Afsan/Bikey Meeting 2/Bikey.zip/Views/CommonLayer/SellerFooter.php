<hr class="my-5">
<footer class="footer">
    <div class="container">
        <p class="text-muted text-center">&copy 2023 Webtech Project</p>
    </div>
</footer>
</body>

</html>