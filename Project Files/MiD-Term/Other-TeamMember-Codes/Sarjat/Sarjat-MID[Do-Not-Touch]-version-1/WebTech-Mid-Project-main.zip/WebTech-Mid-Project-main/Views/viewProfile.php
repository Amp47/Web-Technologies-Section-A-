<?php
    session_start();
    require_once '../Controllers/userController.php';
    showProfile();


?>